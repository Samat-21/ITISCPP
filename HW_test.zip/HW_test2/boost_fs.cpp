#include <iostream>
#include <fstream>
#include <ctime> // std::ctime, std::time_t

#include <boost/filesystem/operations.hpp>

namespace fs = boost::filesystem;

void test_path() {
  fs::path p("./file.ext"); // relative path

  // create file
  std::ofstream file(p.string());
  file << "Hello, World";
  file.close();

  try {
    // filename
    std::cout << p.stem() << std::endl;
    
    // absolute path
    std::cout << fs::canonical(p.parent_path()) << std::endl; // absolute path
    
    // file size
    if (fs::exists(p))
      std::cout << fs::file_size(p) << std::endl;

    // last write time
    std::time_t t = fs::last_write_time(p);
    std::cout << std::ctime(&t) << std::endl;
  } catch(const fs::filesystem_error& e) {
    std::cerr << e.what();
  }
}

void copy_file() {
  fs::path src("file.ext");

  try {
    fs::path dest("test/file.ext");
    if (!fs::exists(dest.parent_path())) {
      fs::create_directory(dest.parent_path());
    }
    fs::copy(src, dest);
  } catch(const fs::filesystem_error& e) {
    std::cerr << e.what();
  }
}

void copy_dirs() {
  fs::path src("test");
  fs::path dest("test2");

  try {
    if (fs::is_directory(src)) {
      fs::create_directory(dest);
      for (const auto& entry : fs::directory_iterator(src)) {
        fs::copy_file(entry.path(), dest/entry.path().filename());
      }
    }
  } catch(const fs::filesystem_error& e) {
    std::cerr << e.what();
  }
}

void remove_file() {
  fs::path src("test2");

  try {
    if (fs::is_directory(src)) {
      for (const auto& entry : fs::directory_iterator(src)) {
        if (entry.path().filename() == "Makefile")
          fs::remove(entry);
      }
    }
  } catch(const fs::filesystem_error& e) {
    std::cerr << e.what();
  }
}

void remove_all() {
  fs::path src("test2");

  try {
    if (fs::is_directory(src)) {
      fs::remove_all(src);
    }
  } catch(const fs::filesystem_error& e) {
    std::cerr << e.what();
  }
}

void simple_ls(const fs::path& in_folder) {
  if (fs::exists(in_folder)) {
    if (fs::is_regular_file(in_folder)) {
      std::cout << "Regular file: " << in_folder << std::endl;
    } else if (fs::is_directory(in_folder)) {
      for (const auto& entry : fs::directory_iterator(in_folder)) {
        std::cout << "Entry: " << entry << std::endl;
        fs::file_status st = entry.status();
        switch (st.type())
        {
          case fs::regular_file:
            std::cout << "Type: File" << std::endl;
            break;

          case fs::directory_file:
            std::cout << "Type: Directory" << std::endl;
            simple_ls(entry);
            break;
          
          default:
            break;
        }
      }
    }
  } else {
    std::cout << in_folder << " does not exist!\n";
  }
}

int main()
{

  //test_path();

  //copy_file();

  //copy_dirs();

  //remove_file();

  //remove_all();

  fs::path in_folder = ".";
  try {
    simple_ls(in_folder);
  } catch (const fs::filesystem_error& exc) {
    std::cerr << exc.what() << std::endl;
  }  

  return 0;
}